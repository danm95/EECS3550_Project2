EECS3550_Project2
Name: Daniel McGinnis
Name: Riley Robinson
Project: The primary goal of this exercise is to develop an expression verifier for a dynamic document structure. A secondary goal is to develop the skills required for working as part of a team.
Status: Fully Functional